'use strict';

const MAX_IMAGE_BYTES = 4 * 1024 * 1024;
const MIN_IMAGE_BYTES = 100;
const COOLDOWN_MS = 30_000;
const recentSends = new Map();

function json(statusCode, value) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff'
    },
    body: JSON.stringify(value)
  };
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { ...json(405, { ok: false, error: 'Method not allowed.' }), headers: { ...json(405, {}).headers, allow: 'POST' } };
  }

  const origin = event.headers?.origin;
  let requestHost = event.headers?.host;
  try {
    if (event.rawUrl) requestHost = new URL(event.rawUrl).host;
  } catch (_) {}
  if (!origin || !requestHost) {
    return json(403, { ok: false, error: 'Request origin could not be verified.' });
  }
  try {
    const originUrl = new URL(origin);
    if (originUrl.protocol !== 'https:' || originUrl.host.toLowerCase() !== requestHost.toLowerCase()) {
      return json(403, { ok: false, error: 'Request origin could not be verified.' });
    }
  } catch (_) {
    return json(403, { ok: false, error: 'Request origin could not be verified.' });
  }

  const contentType = String(event.headers?.['content-type'] || '').toLowerCase();
  if (!contentType.startsWith('image/jpeg')) {
    return json(415, { ok: false, error: 'Only JPEG images are accepted.' });
  }
  if (!event.body) return json(400, { ok: false, error: 'Image body is empty.' });

  let photo;
  try {
    photo = Buffer.from(event.body, event.isBase64Encoded ? 'base64' : 'binary');
  } catch (_) {
    return json(400, { ok: false, error: 'Image body could not be read.' });
  }
  if (photo.length < MIN_IMAGE_BYTES) return json(400, { ok: false, error: 'Image body is too small.' });
  if (photo.length > MAX_IMAGE_BYTES) return json(413, { ok: false, error: 'Image exceeds the 4 MiB limit.' });
  if (photo[0] !== 0xff || photo[1] !== 0xd8 || photo[2] !== 0xff) {
    return json(415, { ok: false, error: 'Uploaded content is not a valid JPEG.' });
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) {
    return json(503, { ok: false, error: 'Server is not configured. Add TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in Netlify environment variables.' });
  }

  const clientIp = event.headers?.['x-nf-client-connection-ip'] || event.headers?.['client-ip'] || 'unknown-client';
  const now = Date.now();
  for (const [ip, sentAt] of recentSends) {
    if (now - sentAt > COOLDOWN_MS) recentSends.delete(ip);
  }
  const previous = recentSends.get(clientIp);
  if (previous && now - previous < COOLDOWN_MS) {
    return json(429, { ok: false, error: 'Please wait before sending another image.' });
  }

  const form = new FormData();
  form.append('chat_id', chatId);
  form.append('caption', 'صورة أرسلها الزائر بعد موافقة صريحة على التصوير والإرسال.');
  form.append('photo', new Blob([photo], { type: 'image/jpeg' }), 'visitor-photo.jpg');

  let telegramResponse;
  try {
    telegramResponse = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, {
      method: 'POST',
      body: form
    });
  } catch (_) {
    return json(502, { ok: false, error: 'Could not connect to Telegram. Check server network and configuration.' });
  }

  let telegramResult;
  try { telegramResult = await telegramResponse.json(); } catch (_) { telegramResult = null; }
  if (!telegramResponse.ok || !telegramResult?.ok) {
    // Do not leak the bot token or Telegram's raw response details to site visitors.
    return json(502, { ok: false, error: 'Telegram rejected the image. Check the bot token, chat ID, and that the bot can message this chat.' });
  }

  recentSends.set(clientIp, now);
  return json(200, { ok: true });
};
