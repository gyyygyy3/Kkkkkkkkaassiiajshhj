Netlify deployment package
==========================

The static site is in /site. The Netlify Function source is in /netlify/functions/send-photo.js.
The /send-photo path is routed through netlify.toml. Configure TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID as Netlify environment variables; do not place tokens in client-side files.

Important: the previous archive exposed a Telegram bot token. Revoke that token in BotFather and create a new one before configuring this deployment.

Deploy from a connected Git repository or the Netlify CLI so the function is bundled and deployed. A static drag-and-drop deploy alone may not deploy Functions.
